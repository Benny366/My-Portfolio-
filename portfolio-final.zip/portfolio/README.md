# Paul Benjamin: Developer Portfolio

React + TypeScript + Vite + Tailwind CSS + Framer Motion + Lucide icons. Static site, no backend to maintain.

## Run it on your computer

Requires Node.js 20 or newer (https://nodejs.org).

```bash
npm install
npm run dev        # opens http://localhost:5173
npm run build      # production build into /dist
npm run preview    # test the production build locally
```

## Where to edit things

| What | File |
| --- | --- |
| Name, links, email, resume path, education | `src/config/site.ts` |
| Projects (links, images, your contribution) | `src/data/projects.ts` |
| Skills, interests, game projects, achievements | `src/data/content.ts` |
| Profile photo | `public/profile.jpg` |
| Resume PDF | `public/resume/Paul_Benjamin_Resume.pdf` |
| Project images | `public/projects/` |
| Email / LinkedIn / contact form / CGPA | `.env` (copy from `.env.example`) |

Rules built in: empty links show "coming soon" buttons, the Achievements section is hidden until you add real entries, CGPA is hidden until you set `VITE_SHOW_CGPA=true`, and the resume button works only when the PDF exists.

## Deployment

See [DEPLOYMENT.md](./DEPLOYMENT.md) for the full beginner guide (GitHub Pages, Vercel, custom domain).

**GitHub Pages users:** in Settings -> Pages choose Source = "GitHub Actions". Choosing "Deploy from a branch" only shows this README.
