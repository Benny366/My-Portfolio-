Put your resume here and name it exactly:

    Paul_Benjamin_Resume.pdf

Until that file exists, the "Download Resume" buttons show "Resume coming soon".
Once it is added (and the site is redeployed), the buttons turn into working download links automatically.
