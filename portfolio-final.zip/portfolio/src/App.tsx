import { BrowserRouter, Route, Routes } from 'react-router-dom'
import About from './components/About'
import Achievements from './components/Achievements'
import Contact from './components/Contact'
import Education from './components/Education'
import Footer, { BackToTop } from './components/Footer'
import GameDev from './components/GameDev'
import Hero from './components/Hero'
import Interests from './components/Interests'
import Navbar from './components/Navbar'
import NotFound from './components/NotFound'
import Projects from './components/Projects'
import Skills from './components/Skills'
import { useTheme } from './hooks/useTheme'

function Home() {
  const { dark, toggle } = useTheme()
  return (
    <>
      <a
        href="#about"
        className="sr-only z-[70] rounded-lg bg-electric px-4 py-2 text-white focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Skip to content
      </a>
      <Navbar dark={dark} toggleTheme={toggle} />
      <main>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <GameDev />
        <Education />
        <Interests />
        <Achievements />
        <Contact />
      </main>
      <Footer />
      <BackToTop />
    </>
  )
}

export default function App() {
  return (
    <BrowserRouter basename={import.meta.env.BASE_URL}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  )
}
