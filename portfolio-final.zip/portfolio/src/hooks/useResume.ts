import { useEffect, useState } from 'react'
import { site } from '../config/site'

/**
 * Checks whether the real resume PDF has been added.
 * A host that rewrites unknown URLs to index.html would answer 200 with HTML, so the content type is verified too.
 */
export function useResume() {
  const [available, setAvailable] = useState(false)

  useEffect(() => {
    let cancelled = false
    fetch(site.resumePath, { method: 'HEAD' })
      .then((r) => {
        const type = r.headers.get('content-type') ?? ''
        if (!cancelled) setAvailable(r.ok && type.includes('pdf'))
      })
      .catch(() => {
        if (!cancelled) setAvailable(false)
      })
    return () => {
      cancelled = true
    }
  }, [])

  return available
}
