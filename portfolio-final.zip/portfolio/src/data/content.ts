/** Skills, interests, game dev, and achievements content. All editable. */

export interface SkillGroup {
  title: string
  icon: 'code' | 'globe' | 'brain' | 'gamepad' | 'glasses' | 'server' | 'wrench'
  items: string[]
}

/** Core programming skills are shown separately from tools used in projects. */
export const coreSkills: SkillGroup = {
  title: 'Core Programming',
  icon: 'code',
  items: ['Java', 'Python', 'SQL'],
}

export const skillGroups: SkillGroup[] = [
  { title: 'Web Development', icon: 'globe', items: ['HTML', 'CSS'] },
  {
    title: 'AI & Machine Learning',
    icon: 'brain',
    items: ['Machine Learning', 'Deep Learning', 'CNN', 'ResNet50', 'CBAM', 'XGBoost', 'LSTM', 'PyTorch', 'TensorFlow'],
  },
  {
    title: 'Game Development',
    icon: 'gamepad',
    items: ['Unity', 'C#', '2D & 3D Game Development', 'Game Mechanics', 'Interactive Environments', 'Game Prototyping'],
  },
  {
    title: 'AR / VR Development',
    icon: 'glasses',
    items: ['Augmented Reality', 'Virtual Reality', 'AR Foundation', 'ARCore', '3D Interactive Experiences'],
  },
  { title: 'Backend & Data', icon: 'server', items: ['FastAPI', 'PostgreSQL', 'Power BI', 'Grafana'] },
  { title: 'Tools', icon: 'wrench', items: ['Git', 'GitHub', 'VS Code', 'Unity Editor'] },
]

export const interests = [
  { icon: 'code', title: 'Software Development', text: 'Writing clean, practical code and improving through building real things.' },
  { icon: 'brain', title: 'AI & Machine Learning', text: 'Applying machine learning and deep learning to real-world problems.' },
  { icon: 'gamepad', title: 'Game Development', text: 'Exploring game mechanics and interactive worlds with Unity and C#.' },
  { icon: 'glasses', title: 'AR/VR Development', text: 'Experimenting with immersive 3D experiences using AR and VR tools.' },
  { icon: 'globe', title: 'Web Development', text: 'Building responsive, accessible websites and web applications.' },
] as const

export const gameFocus = [
  { icon: 'box', title: 'Unity Game Engine', text: 'Scenes, prefabs and the Unity Editor workflow.' },
  { icon: 'terminal', title: 'C# Programming', text: 'Scripting gameplay behaviour and logic.' },
  { icon: 'square', title: '2D Game Development', text: 'Sprite-based games and simple mechanics.' },
  { icon: 'cube', title: '3D Game Development', text: 'Working with 3D assets, cameras and lighting.' },
  { icon: 'cog', title: 'Game Mechanics & Logic', text: 'Designing rules, input and game state.' },
  { icon: 'mountain', title: 'Interactive 3D Environments', text: 'Spaces the user can explore and interact with.' },
  { icon: 'glasses', title: 'AR/VR Experiences', text: 'AR Foundation and ARCore based experiences.' },
  { icon: 'flask', title: 'Game Prototyping', text: 'Quickly testing ideas before polishing them.' },
] as const

export interface GameProject {
  id: string
  title: string
  description: string
  tech: string[]
  github: string
  playDemo: string
  video: string
  screenshot: string
}

/**
 * GAME PROJECTS: starts EMPTY on purpose (no invented games).
 * To add a game, push an object like:
 * { id: 'my-game', title: 'My Game', description: '...', tech: ['Unity','C#'],
 *   github: 'https://github.com/benny366/my-game', playDemo: '', video: '', screenshot: '/projects/my-game.png' }
 * "Play Demo" appears only when playDemo is set.
 */
export const gameProjects: GameProject[] = []

/** Game Development Experiments: add small prototypes here. Empty = a "coming soon" placeholder is shown. */
export const gameExperiments: { id: string; title: string; note: string; link: string }[] = []

export interface Achievement {
  title: string
  issuer: string
  date: string
  type: 'Certification' | 'Coding' | 'Workshop' | 'Hackathon' | 'Academic' | 'Course'
  link: string
}

/**
 * ACHIEVEMENTS: starts EMPTY, so the whole section stays hidden until you add real entries.
 * Example: { title: 'Course name', issuer: 'Platform', date: '2026', type: 'Course', link: 'https://...' }
 */
export const achievements: Achievement[] = []
