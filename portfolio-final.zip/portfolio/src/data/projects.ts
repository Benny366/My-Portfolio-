/**
 * PROJECT DATA: edit freely.
 * - github / demo: leave '' until the real link exists. The buttons then show as "coming soon".
 * - thumbnail: leave '' to use a generated gradient. To use an image, drop it in public/projects/ and
 *   set e.g. '/projects/predictive-maintenance.png'.
 * - media: optional screenshots / video list: { type: 'image' | 'video', src, caption }.
 * - contribution: written conservatively. Edit it to describe exactly what YOU did.
 */
export type ProjectCategory = 'AI / ML' | 'Deep Learning' | 'Web Development' | 'Data Analysis' | 'AR / Interactive'

export interface Project {
  id: string
  title: string
  category: ProjectCategory
  categoryLabel: string
  featured?: boolean
  problem: string
  description: string
  contribution: string
  tech: string[]
  github: string
  demo: string
  thumbnail: string
  gradient: string
  media: { type: 'image' | 'video'; src: string; caption: string }[]
}

export const projects: Project[] = [
  {
    id: 'predict-before-it-breaks',
    title: 'Predict Before It Breaks – Industrial AI',
    category: 'AI / ML',
    categoryLabel: 'Artificial Intelligence | Machine Learning',
    featured: true,
    problem:
      'Unexpected equipment failures in industrial settings cause downtime and cost. Early warning from sensor data can allow maintenance to be planned instead of reactive.',
    description:
      'An AI-powered industrial predictive maintenance system that analyzes machine sensor readings, including temperature, vibration, pressure, current, and RPM. The system identifies abnormal patterns, detects potential equipment failures, estimates failure probability, calculates Remaining Useful Life (RUL), and provides maintenance recommendations.',
    contribution: 'Add a short description of your role: for example model development, data pipeline, API or dashboard work.',
    tech: ['Python', 'XGBoost', 'LSTM', 'PostgreSQL', 'FastAPI', 'Power BI / Grafana'],
    github: '',
    demo: '',
    thumbnail: '',
    gradient: 'from-blue-600/40 via-indigo-600/30 to-violet-600/40',
    media: [],
  },
  {
    id: 'waste-classification',
    title: 'Waste & Garbage Image Classification',
    category: 'Deep Learning',
    categoryLabel: 'Deep Learning | Computer Vision',
    problem:
      'Sorting waste correctly is essential for recycling. Automatically identifying waste categories from images can support smarter segregation.',
    description:
      'A deep-learning image classification project designed to identify waste categories using different neural network architectures. It explores conventional CNNs, attention-enhanced architectures, modern neural networks, and Vision Transformers.',
    contribution: 'Add a short description of your role: for example training experiments, architecture comparison, evaluation.',
    tech: ['Python', 'PyTorch', 'ResNet50', 'CBAM', 'CNN', 'Vision Transformers'],
    github: '',
    demo: '',
    thumbnail: '',
    gradient: 'from-emerald-500/30 via-cyan-600/30 to-blue-600/40',
    media: [],
  },
  {
    id: 'aajm-church-website',
    title: 'AAJM Church Website',
    category: 'Web Development',
    categoryLabel: 'Web Development',
    problem:
      'A ministry needed a clear online presence where visitors can find information and online resources.',
    description:
      'A responsive website developed for Agape Agni Jwala Ministries to present ministry information and online resources.',
    contribution: 'Add a short description of your role: for example design, HTML/CSS development, content setup.',
    tech: ['HTML', 'CSS', 'Web Technologies'],
    github: '',
    demo: '',
    thumbnail: '',
    gradient: 'from-orange-500/30 via-rose-600/30 to-violet-600/40',
    media: [],
  },
  {
    id: 'food-analysis',
    title: 'Food Analysis',
    category: 'Data Analysis',
    categoryLabel: 'Python | Data Analysis',
    problem: 'Food-related data holds patterns that become useful only after it is cleaned, explored and analyzed.',
    description:
      'A project focused on analyzing food-related information using programming and data analysis techniques.',
    contribution: 'Add a short description of your role: for example data cleaning, analysis, visualizations.',
    tech: ['Python', 'Data Analysis'],
    github: '',
    demo: '',
    thumbnail: '',
    gradient: 'from-amber-500/30 via-lime-600/25 to-emerald-600/35',
    media: [],
  },
  {
    id: 'ar-virtual-dress-shopping',
    title: 'AR Virtual Dress Shopping',
    category: 'AR / Interactive',
    categoryLabel: 'Augmented Reality | Interactive Development',
    problem:
      'Online clothes shopping makes it hard to picture how items look. Augmented reality can make browsing more interactive.',
    description:
      'An AR-based virtual shopping concept that allows users to explore virtual clothing and interactive 3D experiences.',
    contribution: 'Add a short description of your role: for example Unity scenes, C# scripting, AR setup.',
    tech: ['Unity', 'C#', 'AR Foundation', 'ARCore'],
    github: '',
    demo: '',
    thumbnail: '',
    gradient: 'from-fuchsia-500/30 via-violet-600/35 to-blue-600/40',
    media: [],
  },
]

export const projectFilters: ('All' | ProjectCategory)[] = [
  'All',
  'AI / ML',
  'Deep Learning',
  'Web Development',
  'Data Analysis',
  'AR / Interactive',
]
