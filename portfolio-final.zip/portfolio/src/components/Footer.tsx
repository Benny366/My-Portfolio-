import { ArrowUp } from 'lucide-react'
import { useEffect, useState } from 'react'
import { site } from '../config/site'
import { SocialLinks } from './Hero'

export function BackToTop() {
  const [show, setShow] = useState(false)
  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 600)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])
  if (!show) return null
  return (
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      aria-label="Back to top"
      className="fixed bottom-6 right-6 z-40 rounded-full bg-gradient-to-br from-electric to-violet p-3.5 text-white shadow-xl shadow-violet/30 transition-transform hover:-translate-y-1"
    >
      <ArrowUp className="h-5 w-5" />
    </button>
  )
}

export default function Footer() {
  return (
    <footer className="border-t border-line py-10">
      <div className="container-x flex flex-col items-center justify-between gap-5 sm:flex-row">
        <p className="text-sm text-muted">
          © {new Date().getFullYear()} {site.name}. Built with React, TypeScript & Tailwind CSS.
        </p>
        <SocialLinks />
      </div>
    </footer>
  )
}
