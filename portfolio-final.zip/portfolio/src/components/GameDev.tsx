import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion'
import { ExternalLink, FlaskConical, Play, Plus, Video } from 'lucide-react'
import type { MouseEvent } from 'react'
import { asset } from '../config/site'
import { gameExperiments, gameFocus, gameProjects, type GameProject } from '../data/content'
import { GithubIcon, Icon } from './icons'
import { LinkButton, Reveal, SectionHeading } from './ui'

/** Card that tilts toward the cursor for a subtle 3D feel. */
function TiltCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const x = useMotionValue(0)
  const y = useMotionValue(0)
  const rx = useSpring(useTransform(y, [-0.5, 0.5], [8, -8]), { stiffness: 200, damping: 20 })
  const ry = useSpring(useTransform(x, [-0.5, 0.5], [-8, 8]), { stiffness: 200, damping: 20 })

  const onMove = (e: MouseEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect()
    x.set((e.clientX - r.left) / r.width - 0.5)
    y.set((e.clientY - r.top) / r.height - 0.5)
  }
  const reset = () => {
    x.set(0)
    y.set(0)
  }

  return (
    <div style={{ perspective: 900 }}>
      <motion.div
        onMouseMove={onMove}
        onMouseLeave={reset}
        style={{ rotateX: rx, rotateY: ry, transformStyle: 'preserve-3d' }}
        className={className}
      >
        {children}
      </motion.div>
    </div>
  )
}

function GameCard({ g }: { g: GameProject }) {
  return (
    <TiltCard className="glass overflow-hidden rounded-3xl">
      <div className="relative aspect-video bg-surface2">
        {g.screenshot ? (
          <img src={asset(g.screenshot)} alt={`${g.title} screenshot`} loading="lazy" className="h-full w-full object-cover" />
        ) : g.video ? (
          <video src={asset(g.video)} controls preload="none" className="h-full w-full object-cover" aria-label={`${g.title} demo video`} />
        ) : (
          <div className="flex h-full items-center justify-center text-muted">
            <Video className="h-8 w-8" />
          </div>
        )}
      </div>
      <div className="space-y-3 p-6">
        <h4 className="font-display text-xl font-bold">{g.title}</h4>
        <p className="text-sm text-muted">{g.description}</p>
        <ul className="flex flex-wrap gap-2">
          {g.tech.map((t) => (
            <li key={t} className="tag">{t}</li>
          ))}
        </ul>
        <div className="flex flex-wrap gap-2 pt-2">
          {g.playDemo && (
            <LinkButton href={g.playDemo} soonLabel="" variant="primary" icon={<Play className="h-4 w-4" />}>
              Play Demo
            </LinkButton>
          )}
          <LinkButton href={g.github} soonLabel="Repo coming soon" icon={<GithubIcon className="h-4 w-4" />}>
            GitHub
          </LinkButton>
        </div>
      </div>
    </TiltCard>
  )
}

export default function GameDev() {
  return (
    <section id="game-dev" className="section">
      <div className="absolute inset-0 -z-0 bg-gradient-to-b from-transparent via-violet/[0.06] to-transparent" aria-hidden="true" />
      <div className="container-x relative">
        <SectionHeading
          eyebrow="04 / Interactive"
          title="GAME DEVELOPMENT & INTERACTIVE EXPERIENCES"
          subtitle="I am interested in developing interactive digital experiences using game development technologies."
        />

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {gameFocus.map((f, i) => (
            <Reveal key={f.title} delay={i * 0.05}>
              <TiltCard className="glass h-full rounded-2xl p-5">
                <div className="mb-3 inline-flex rounded-xl bg-gradient-to-br from-electric/25 to-violet/25 p-2.5 text-electric" style={{ transform: 'translateZ(30px)' }}>
                  <Icon name={f.icon} />
                </div>
                <h3 className="font-display font-semibold" style={{ transform: 'translateZ(20px)' }}>{f.title}</h3>
                <p className="mt-1 text-sm text-muted">{f.text}</p>
              </TiltCard>
            </Reveal>
          ))}
        </div>

        <div className="mt-14">
          <h3 className="mb-6 font-display text-2xl font-bold">Game & Interactive Projects</h3>
          {gameProjects.length === 0 ? (
            <Reveal>
              <div className="glass rounded-3xl border-dashed p-8 text-center">
                <Video className="mx-auto mb-3 h-8 w-8 text-muted" />
                <p className="font-medium">Game demos and videos are coming soon.</p>
                <p className="mx-auto mt-2 max-w-md text-sm text-muted">
                  This space is ready for screenshots, video demonstrations, Play Demo buttons and GitHub repositories as soon as projects are published.
                </p>
                <a href="#projects" className="btn-ghost mt-5 !py-2.5">
                  <ExternalLink className="h-4 w-4" /> See my AR project meanwhile
                </a>
              </div>
            </Reveal>
          ) : (
            <div className="grid gap-6 md:grid-cols-2">
              {gameProjects.map((g) => (
                <GameCard key={g.id} g={g} />
              ))}
            </div>
          )}
        </div>

        <div className="mt-14">
          <h3 className="mb-6 flex items-center gap-2 font-display text-2xl font-bold">
            <FlaskConical className="h-6 w-6 text-violet" /> Game Development Experiments
          </h3>
          {gameExperiments.length === 0 ? (
            <Reveal>
              <div className="glass flex flex-col items-center gap-2 rounded-3xl border-dashed p-8 text-center">
                <Plus className="h-7 w-7 text-muted" />
                <p className="font-medium">Experiments and prototypes will appear here.</p>
                <p className="max-w-md text-sm text-muted">A space for small mechanics tests, prototypes and learning builds as I create them.</p>
              </div>
            </Reveal>
          ) : (
            <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {gameExperiments.map((e) => (
                <li key={e.id} className="glass rounded-2xl p-5">
                  <h4 className="font-semibold">{e.title}</h4>
                  <p className="mt-1 text-sm text-muted">{e.note}</p>
                  {e.link && (
                    <a href={e.link} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-1 text-sm text-electric">
                      Open <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  )}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </section>
  )
}
