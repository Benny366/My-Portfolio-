import { Home } from 'lucide-react'
import { useEffect } from 'react'

export default function NotFound() {
  useEffect(() => {
    const prev = document.title
    document.title = '404 – Page not found | Paul Benjamin'
    return () => {
      document.title = prev
    }
  }, [])

  return (
    <main className="relative flex min-h-screen items-center justify-center overflow-hidden px-6 text-center">
      <div className="grid-bg pointer-events-none absolute inset-0" aria-hidden="true" />
      <div className="pointer-events-none absolute left-1/2 top-1/3 h-80 w-80 -translate-x-1/2 rounded-full bg-violet/25 blur-[110px]" aria-hidden="true" />
      <div className="relative">
        <p className="font-mono text-sm text-electric">ERROR 404</p>
        <h1 className="mt-2 font-display text-7xl font-bold gradient-text sm:text-9xl">404</h1>
        <p className="mt-4 text-xl font-semibold">This page could not be found.</p>
        <p className="mx-auto mt-2 max-w-md text-muted">The link may be broken or the page may have moved. Let's get you back.</p>
        <a href={import.meta.env.BASE_URL} className="btn-primary mt-8">
          <Home className="h-4 w-4" /> Back to portfolio
        </a>
      </div>
    </main>
  )
}
