import { motion } from 'framer-motion'
import { ArrowDown, Download, Mail, MapPin } from 'lucide-react'
import { site } from '../config/site'
import { useResume } from '../hooks/useResume'
import { GithubIcon, LinkedinIcon } from './icons'

export function SocialLinks({ className = '' }: { className?: string }) {
  const items = [
    { href: site.github, label: 'GitHub', icon: <GithubIcon /> },
    { href: site.linkedin, label: 'LinkedIn', icon: <LinkedinIcon /> },
    { href: site.email ? `mailto:${site.email}` : '', label: 'Email', icon: <Mail className="h-5 w-5" /> },
  ].filter((i) => i.href)

  return (
    <ul className={`flex items-center gap-3 ${className}`}>
      {items.map((i) => (
        <li key={i.label}>
          <a
            href={i.href}
            aria-label={i.label}
            {...(i.href.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
            className="glass flex h-11 w-11 items-center justify-center rounded-xl text-muted transition-all hover:-translate-y-0.5 hover:border-electric/60 hover:text-fg"
          >
            {i.icon}
          </a>
        </li>
      ))}
    </ul>
  )
}

export function ResumeButton({ variant = 'ghost' }: { variant?: 'primary' | 'ghost' }) {
  const available = useResume()
  if (!available) {
    return (
      <span className="btn-disabled" role="link" aria-disabled="true" title="Resume PDF will be added soon">
        <Download className="h-4 w-4" /> Resume coming soon
      </span>
    )
  }
  return (
    <a href={site.resumePath} download="Paul_Benjamin_Resume.pdf" className={variant === 'primary' ? 'btn-primary' : 'btn-ghost'}>
      <Download className="h-4 w-4" /> Download Resume
    </a>
  )
}

export default function Hero() {
  return (
    <section id="top" className="relative flex min-h-screen items-center overflow-hidden pt-24 pb-16">
      <div className="grid-bg pointer-events-none absolute inset-0" aria-hidden="true" />
      <div className="pointer-events-none absolute -left-32 top-20 h-96 w-96 animate-pulseGlow rounded-full bg-electric/25 blur-[120px]" aria-hidden="true" />
      <div className="pointer-events-none absolute -right-32 bottom-10 h-96 w-96 animate-pulseGlow rounded-full bg-violet/25 blur-[120px]" aria-hidden="true" />

      <div className="container-x relative grid items-center gap-12 lg:grid-cols-[1.25fr_1fr]">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="glass mb-6 inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs text-muted"
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            {site.availability}
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="font-mono text-sm text-electric"
          >
            Hello, I'm
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-2 font-display text-4xl font-bold uppercase leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl"
          >
            Nagishetti <span className="gradient-text">Paul Benjamin</span>
          </motion.h1>
          <motion.h2
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.35 }}
            className="mt-5 text-lg font-medium sm:text-xl"
          >
            {site.role}
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="mt-2 font-display text-xl font-semibold gradient-text"
          >
            {site.tagline}
          </motion.p>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="mt-5 max-w-xl text-muted"
          >
            {site.intro}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.75 }}
            className="mt-8 flex flex-wrap gap-3"
          >
            <a href="#projects" className="btn-primary">
              Explore My Work <ArrowDown className="h-4 w-4" />
            </a>
            <ResumeButton />
            <a href="#contact" className="btn-ghost">
              <Mail className="h-4 w-4" /> Contact Me
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            className="mt-8 flex flex-wrap items-center gap-5"
          >
            <SocialLinks />
            <span className="flex items-center gap-1.5 text-sm text-muted">
              <MapPin className="h-4 w-4" /> {site.location}
            </span>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="relative mx-auto w-full max-w-sm animate-float"
        >
          <div className="absolute -inset-1 rounded-[2rem] bg-gradient-to-br from-electric to-violet opacity-70 blur-xl" aria-hidden="true" />
          <div className="relative overflow-hidden rounded-[2rem] border border-line bg-surface p-2">
            <img
              src={site.photo}
              alt={`Portrait of ${site.name}`}
              width={720}
              height={720}
              className="aspect-square w-full rounded-[1.5rem] object-cover object-top"
              fetchPriority="high"
            />
          </div>
          <div className="glass absolute -bottom-4 -left-3 rounded-2xl px-4 py-2.5 text-xs shadow-xl">
            <p className="font-mono text-electric">B.Tech CSE</p>
            <p className="text-muted">SR University · 2027</p>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
