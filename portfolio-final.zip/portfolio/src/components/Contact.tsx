import { CheckCircle2, Loader2, Mail, Send, TriangleAlert } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { site } from '../config/site'
import { GithubIcon, LinkedinIcon } from './icons'
import { ResumeButton } from './Hero'
import { Reveal } from './ui'

type Status = 'idle' | 'sending' | 'success' | 'error'

export default function Contact() {
  const [status, setStatus] = useState<Status>('idle')
  const [error, setError] = useState('')
  const configured = Boolean(site.contactFormEndpoint)

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    if (!configured) return
    const form = e.currentTarget
    const data = new FormData(form)
    // Honeypot: real visitors never fill this hidden field.
    if (data.get('company')) return

    setStatus('sending')
    setError('')
    try {
      const res = await fetch(site.contactFormEndpoint, {
        method: 'POST',
        body: data,
        headers: { Accept: 'application/json' },
      })
      if (!res.ok) throw new Error('Request failed')
      setStatus('success')
      form.reset()
    } catch {
      setStatus('error')
      setError(
        site.email
          ? `Something went wrong. Please email me directly at ${site.email}.`
          : 'Something went wrong. Please try again in a moment.',
      )
    }
  }

  const field =
    'w-full rounded-xl border border-line bg-surface2/60 px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted/70 focus:border-electric focus:ring-2 focus:ring-electric/30'

  return (
    <section id="contact" className="section">
      <div className="container-x">
        <Reveal>
          <div className="glass relative overflow-hidden rounded-[2rem] p-6 sm:p-12">
            <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-violet/25 blur-[100px]" aria-hidden="true" />
            <div className="relative grid gap-10 lg:grid-cols-2">
              <div>
                <p className="mb-3 font-mono text-xs uppercase tracking-[0.25em] text-electric">08 / Contact</p>
                <h2 className="font-display text-3xl font-bold uppercase leading-tight sm:text-4xl">
                  Let's build something <span className="gradient-text">great together.</span>
                </h2>
                <p className="mt-4 text-muted">
                  I am always interested in learning, collaborating, and exploring opportunities in software development and emerging technologies.
                </p>

                <ul className="mt-8 space-y-3 text-sm">
                  {site.email && (
                    <li>
                      <a href={`mailto:${site.email}`} className="flex items-center gap-3 text-muted transition-colors hover:text-fg">
                        <Mail className="h-5 w-5 text-electric" /> {site.email}
                      </a>
                    </li>
                  )}
                  <li>
                    <a href={site.github} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 text-muted transition-colors hover:text-fg">
                      <GithubIcon className="h-5 w-5 text-electric" /> github.com/benny366
                    </a>
                  </li>
                  {site.linkedin && (
                    <li>
                      <a href={site.linkedin} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 text-muted transition-colors hover:text-fg">
                        <LinkedinIcon className="h-5 w-5 text-electric" /> LinkedIn: Paul Benjamin Nagishetti
                      </a>
                    </li>
                  )}
                </ul>

                <div className="mt-8">
                  <ResumeButton variant="primary" />
                </div>
              </div>

              <form onSubmit={onSubmit} className="space-y-4" noValidate={false}>
                <div>
                  <label htmlFor="name" className="mb-1.5 block text-sm font-medium">Name</label>
                  <input id="name" name="name" required autoComplete="name" className={field} placeholder="Your name" />
                </div>
                <div>
                  <label htmlFor="email" className="mb-1.5 block text-sm font-medium">Email</label>
                  <input id="email" name="email" type="email" required autoComplete="email" className={field} placeholder="you@example.com" />
                </div>
                <div>
                  <label htmlFor="message" className="mb-1.5 block text-sm font-medium">Message</label>
                  <textarea id="message" name="message" required rows={5} className={field} placeholder="How can I help?" />
                </div>
                <input type="text" name="company" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden="true" />

                <button type="submit" disabled={!configured || status === 'sending'} className="btn-primary w-full disabled:cursor-not-allowed disabled:opacity-60 disabled:hover:translate-y-0">
                  {status === 'sending' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  {status === 'sending' ? 'Sending…' : 'Send message'}
                </button>

                {!configured && (
                  <p className="flex items-start gap-2 rounded-xl border border-dashed border-line p-3 text-xs text-muted" role="note">
                    <TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" />
                    The contact form is not connected yet.{' '}
                    {site.email ? (
                      <span>
                        Please email <a className="text-electric underline" href={`mailto:${site.email}`}>{site.email}</a> instead.
                      </span>
                    ) : (
                      <span>Please reach out through GitHub{site.linkedin ? ' or LinkedIn' : ''} for now.</span>
                    )}
                  </p>
                )}
                <div aria-live="polite">
                  {status === 'success' && (
                    <p className="flex items-center gap-2 text-sm text-emerald-500">
                      <CheckCircle2 className="h-4 w-4" /> Thanks! Your message has been sent.
                    </p>
                  )}
                  {status === 'error' && (
                    <p className="flex items-center gap-2 text-sm text-red-500">
                      <TriangleAlert className="h-4 w-4" /> {error}
                    </p>
                  )}
                </div>
              </form>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
