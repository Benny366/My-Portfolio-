import { AnimatePresence, motion } from 'framer-motion'
import { ExternalLink, Star, X } from 'lucide-react'
import { useEffect, useState } from 'react'
import { asset } from '../config/site'
import { projectFilters, projects, type Project } from '../data/projects'
import { GithubIcon } from './icons'
import { LinkButton, SectionHeading } from './ui'

function Thumb({ p, className = '' }: { p: Project; className?: string }) {
  if (p.thumbnail) {
    return <img src={asset(p.thumbnail)} alt={`${p.title} thumbnail`} loading="lazy" className={`object-cover ${className}`} />
  }
  return (
    <div className={`relative flex items-center justify-center overflow-hidden bg-gradient-to-br ${p.gradient} ${className}`} aria-hidden="true">
      <div className="grid-bg absolute inset-0 opacity-60" />
      <span className="relative font-display text-5xl font-bold text-fg/80">{p.title.split(/[^A-Za-z]+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('')}</span>
    </div>
  )
}

function Links({ p }: { p: Project }) {
  return (
    <div className="flex flex-wrap gap-2">
      <LinkButton href={p.github} soonLabel="Repository coming soon" icon={<GithubIcon className="h-4 w-4" />}>
        GitHub Repository
      </LinkButton>
      <LinkButton href={p.demo} soonLabel="Demo coming soon" icon={<ExternalLink className="h-4 w-4" />} variant="primary">
        Live Demo
      </LinkButton>
    </div>
  )
}

function Modal({ p, onClose }: { p: Project; onClose: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [onClose])

  return (
    <motion.div
      className="fixed inset-0 z-[60] flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        role="dialog"
        aria-modal="true"
        aria-label={p.title}
        className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-t-3xl border border-line bg-surface sm:rounded-3xl"
        initial={{ y: 40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 40, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative">
          <Thumb p={p} className="h-48 w-full" />
          <button onClick={onClose} aria-label="Close" className="glass absolute right-4 top-4 rounded-xl p-2">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="space-y-6 p-6 sm:p-8">
          <div>
            <p className="font-mono text-xs uppercase tracking-wider text-electric">{p.categoryLabel}</p>
            <h3 className="mt-1 font-display text-2xl font-bold">{p.title}</h3>
          </div>
          <div>
            <h4 className="mb-1 text-sm font-semibold">Problem statement</h4>
            <p className="text-sm text-muted">{p.problem}</p>
          </div>
          <div>
            <h4 className="mb-1 text-sm font-semibold">Project description</h4>
            <p className="text-sm text-muted">{p.description}</p>
          </div>
          <div>
            <h4 className="mb-1 text-sm font-semibold">My contribution</h4>
            <p className="text-sm text-muted">{p.contribution}</p>
          </div>
          <div>
            <h4 className="mb-2 text-sm font-semibold">Technologies used</h4>
            <ul className="flex flex-wrap gap-2">
              {p.tech.map((t) => (
                <li key={t} className="tag">{t}</li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="mb-2 text-sm font-semibold">Screenshots & demo</h4>
            {p.media.length === 0 ? (
              <p className="rounded-xl border border-dashed border-line p-4 text-sm text-muted">
                Screenshots or a demo video will be added here.
              </p>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2">
                {p.media.map((m) =>
                  m.type === 'video' ? (
                    <video key={m.src} src={asset(m.src)} controls preload="none" className="w-full rounded-xl" aria-label={m.caption} />
                  ) : (
                    <img key={m.src} src={asset(m.src)} alt={m.caption} loading="lazy" className="w-full rounded-xl" />
                  ),
                )}
              </div>
            )}
          </div>
          <Links p={p} />
        </div>
      </motion.div>
    </motion.div>
  )
}

function Card({ p, onOpen, large = false }: { p: Project; onOpen: () => void; large?: boolean }) {
  return (
    <motion.article
      layout
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={{ duration: 0.35 }}
      className={`glass group flex flex-col overflow-hidden rounded-3xl transition-all duration-300 hover:-translate-y-1.5 hover:border-electric/60 hover:shadow-2xl hover:shadow-violet/20 ${large ? 'md:col-span-2 md:flex-row' : ''}`}
    >
      <div className={`overflow-hidden ${large ? 'md:w-5/12' : ''}`}>
        <Thumb p={p} className={`w-full transition-transform duration-500 group-hover:scale-105 ${large ? 'h-48 md:h-full' : 'h-44'}`} />
      </div>
      <div className={`flex flex-1 flex-col p-6 ${large ? 'md:p-8' : ''}`}>
        <div className="mb-2 flex flex-wrap items-center gap-2">
          {p.featured && (
            <span className="inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-electric to-violet px-2.5 py-1 text-[11px] font-semibold text-white">
              <Star className="h-3 w-3" /> Primary project
            </span>
          )}
          <span className="font-mono text-[11px] uppercase tracking-wider text-electric">{p.categoryLabel}</span>
        </div>
        <h3 className={`font-display font-bold ${large ? 'text-2xl' : 'text-xl'}`}>{p.title}</h3>
        <p className={`mt-3 text-sm text-muted ${large ? '' : 'line-clamp-4'}`}>{p.description}</p>
        <ul className="mt-4 flex flex-wrap gap-2">
          {p.tech.map((t) => (
            <li key={t} className="tag">{t}</li>
          ))}
        </ul>
        <div className="mt-auto flex flex-wrap items-center gap-2 pt-6">
          <button onClick={onOpen} className="btn-primary !px-4 !py-2.5">View details</button>
          <LinkButton href={p.github} soonLabel="Repo soon" icon={<GithubIcon className="h-4 w-4" />}>
            GitHub
          </LinkButton>
        </div>
      </div>
    </motion.article>
  )
}

export default function Projects() {
  const [filter, setFilter] = useState<(typeof projectFilters)[number]>('All')
  const [active, setActive] = useState<Project | null>(null)
  const list = projects.filter((p) => filter === 'All' || p.category === filter)

  return (
    <section id="projects" className="section">
      <div className="container-x">
        <SectionHeading
          eyebrow="03 / Projects"
          title="Featured Projects"
          subtitle="Academic and independent projects across AI/ML, web development, data analysis and AR."
        />

        <div className="mb-8 flex flex-wrap gap-2" role="group" aria-label="Filter projects by category">
          {projectFilters.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              aria-pressed={filter === f}
              className={`rounded-full border px-4 py-2 text-sm transition-all ${
                filter === f
                  ? 'border-transparent bg-gradient-to-r from-electric to-violet text-white shadow-lg shadow-violet/25'
                  : 'border-line text-muted hover:border-electric/60 hover:text-fg'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        <motion.div layout className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {list.map((p) => (
              <Card key={p.id} p={p} large={!!p.featured && filter === 'All'} onOpen={() => setActive(p)} />
            ))}
          </AnimatePresence>
        </motion.div>

        <AnimatePresence>{active && <Modal p={active} onClose={() => setActive(null)} />}</AnimatePresence>
      </div>
    </section>
  )
}
