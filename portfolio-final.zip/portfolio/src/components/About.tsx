import { GraduationCap, MapPin, Sparkles } from 'lucide-react'
import { site } from '../config/site'
import { Reveal, SectionHeading } from './ui'

export default function About() {
  return (
    <section id="about" className="section">
      <div className="container-x">
        <SectionHeading eyebrow="01 / About" title="About Me" />
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr]">
          <Reveal className="space-y-5 text-muted leading-relaxed">
            <p>
              I am a Computer Science Engineering student at SR University, graduating in 2027. I am passionate about software
              development, programming, artificial intelligence, machine learning, and interactive technologies.
            </p>
            <p>
              I enjoy learning new technologies and applying my knowledge through academic and independent projects.
            </p>
            <p>
              My interests extend beyond traditional software development into game development, augmented reality, and virtual reality.
            </p>
            <p>
              I believe in continuous learning, practical problem-solving, creativity, and building technology that solves real-world
              problems.
            </p>
            <p className="font-medium text-fg">
              My goal is to grow as a software developer and contribute to innovative engineering projects.
            </p>
          </Reveal>

          <Reveal delay={0.15}>
            <div className="glass space-y-5 rounded-3xl p-6">
              <h3 className="font-display text-lg font-semibold">Quick facts</h3>
              {[
                { icon: <GraduationCap className="h-5 w-5" />, label: 'Education', value: `B.Tech CSE, ${site.education.institution}` },
                { icon: <Sparkles className="h-5 w-5" />, label: 'Graduating', value: site.education.graduation },
                { icon: <MapPin className="h-5 w-5" />, label: 'Location', value: site.location },
                { icon: <Sparkles className="h-5 w-5" />, label: 'Experience', value: 'Fresher' },
              ].map((f) => (
                <div key={f.label} className="flex items-start gap-3">
                  <span className="mt-0.5 rounded-lg bg-electric/15 p-2 text-electric">{f.icon}</span>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-muted">{f.label}</p>
                    <p className="text-sm font-medium">{f.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
