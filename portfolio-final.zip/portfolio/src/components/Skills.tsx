import { coreSkills, skillGroups } from '../data/content'
import { Icon } from './icons'
import { Reveal, SectionHeading } from './ui'

export default function Skills() {
  return (
    <section id="skills" className="section">
      <div className="container-x">
        <SectionHeading
          eyebrow="02 / Skills"
          title="Technical Skills"
          subtitle="Languages I program in, plus the technologies I have used while building projects. I'm still learning and growing in each of them."
        />

        <Reveal>
          <div className="glass mb-6 rounded-3xl border-electric/30 p-6 sm:p-8">
            <div className="mb-4 flex items-center gap-3">
              <span className="rounded-xl bg-gradient-to-br from-electric to-violet p-2.5 text-white">
                <Icon name={coreSkills.icon} />
              </span>
              <div>
                <h3 className="font-display text-xl font-semibold">{coreSkills.title}</h3>
                <p className="text-xs text-muted">My core programming languages</p>
              </div>
            </div>
            <ul className="flex flex-wrap gap-3">
              {coreSkills.items.map((s) => (
                <li key={s} className="rounded-xl border border-electric/40 bg-electric/10 px-5 py-2.5 font-display text-lg font-semibold">
                  {s}
                </li>
              ))}
            </ul>
          </div>
        </Reveal>

        <p className="mb-4 mt-10 font-mono text-xs uppercase tracking-[0.2em] text-muted">Additional technologies used in projects</p>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {skillGroups.map((g, i) => (
            <Reveal key={g.title} delay={i * 0.06}>
              <div className="glass h-full rounded-2xl p-5 transition-all duration-300 hover:-translate-y-1 hover:border-violet/50">
                <div className="mb-4 flex items-center gap-3">
                  <span className="rounded-lg bg-violet/15 p-2 text-violet">
                    <Icon name={g.icon} className="h-4 w-4" />
                  </span>
                  <h3 className="font-display font-semibold">{g.title}</h3>
                </div>
                <ul className="flex flex-wrap gap-2">
                  {g.items.map((s) => (
                    <li key={s} className="tag">
                      {s}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
