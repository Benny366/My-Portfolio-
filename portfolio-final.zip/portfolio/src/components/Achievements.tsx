import { Award, ExternalLink } from 'lucide-react'
import { achievements } from '../data/content'
import { Reveal, SectionHeading } from './ui'

/** Hidden completely until real entries are added in src/data/content.ts. */
export default function Achievements() {
  if (achievements.length === 0) return null
  return (
    <section id="achievements" className="section">
      <div className="container-x">
        <SectionHeading eyebrow="07 / Recognition" title="Achievements & Certifications" />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {achievements.map((a, i) => (
            <Reveal key={`${a.title}-${i}`} delay={i * 0.05}>
              <div className="glass h-full rounded-2xl p-5">
                <Award className="mb-3 h-6 w-6 text-violet" />
                <p className="font-mono text-[11px] uppercase tracking-wider text-electric">{a.type}</p>
                <h3 className="mt-1 font-display font-semibold">{a.title}</h3>
                <p className="mt-1 text-sm text-muted">
                  {a.issuer}
                  {a.date && ` · ${a.date}`}
                </p>
                {a.link && (
                  <a href={a.link} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-1 text-sm text-electric">
                    View <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                )}
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
