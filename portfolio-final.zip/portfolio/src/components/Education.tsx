import { GraduationCap, MapPin } from 'lucide-react'
import { site } from '../config/site'
import { Reveal, SectionHeading } from './ui'

export default function Education() {
  const e = site.education
  return (
    <section id="education" className="section">
      <div className="container-x">
        <SectionHeading eyebrow="05 / Education" title="Education" />
        <div className="relative ml-3 border-l border-line pl-8">
          <span className="absolute -left-[9px] top-2 h-4 w-4 rounded-full bg-gradient-to-br from-electric to-violet ring-4 ring-bg" aria-hidden="true" />
          <Reveal>
            <div className="glass max-w-2xl rounded-3xl p-6 sm:p-8">
              <div className="flex items-start gap-4">
                <span className="rounded-xl bg-electric/15 p-3 text-electric">
                  <GraduationCap className="h-6 w-6" />
                </span>
                <div>
                  <p className="font-mono text-xs uppercase tracking-wider text-electric">Expected graduation {e.graduation}</p>
                  <h3 className="mt-1 font-display text-xl font-bold">{e.institution}</h3>
                  <p className="mt-1 text-fg">{e.degree}</p>
                  <p className="text-sm text-muted">{e.branch}</p>
                  <p className="mt-3 flex items-center gap-1.5 text-sm text-muted">
                    <MapPin className="h-4 w-4" /> {e.location}
                  </p>
                  {e.showCgpa && e.cgpa && (
                    <p className="mt-3 text-sm">
                      <span className="text-muted">CGPA: </span>
                      <span className="font-semibold">{e.cgpa}</span>
                    </p>
                  )}
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
