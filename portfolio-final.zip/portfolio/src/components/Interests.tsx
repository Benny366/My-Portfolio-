import { interests } from '../data/content'
import { Icon } from './icons'
import { Reveal, SectionHeading } from './ui'

export default function Interests() {
  return (
    <section id="interests" className="section">
      <div className="container-x">
        <SectionHeading eyebrow="06 / Interests" title="Career Interests" subtitle="The five areas I want to build my career around." />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {interests.map((it, i) => (
            <Reveal key={it.title} delay={i * 0.07}>
              <div className="glass group h-full rounded-2xl p-6 transition-all duration-300 hover:-translate-y-1 hover:border-electric/60">
                <span className="mb-4 inline-flex rounded-xl bg-gradient-to-br from-electric to-violet p-3 text-white transition-transform group-hover:scale-110">
                  <Icon name={it.icon} className="h-6 w-6" />
                </span>
                <h3 className="font-display text-lg font-semibold">{it.title}</h3>
                <p className="mt-2 text-sm text-muted">{it.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
