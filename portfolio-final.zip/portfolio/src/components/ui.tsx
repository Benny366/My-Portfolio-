import { motion } from 'framer-motion'
import type { ReactNode } from 'react'

export function Reveal({ children, delay = 0, className = '' }: { children: ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  )
}

export function SectionHeading({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle?: string }) {
  return (
    <Reveal className="mb-12 max-w-2xl">
      <p className="mb-3 font-mono text-xs uppercase tracking-[0.25em] text-electric">{eyebrow}</p>
      <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">{title}</h2>
      {subtitle && <p className="mt-4 text-muted">{subtitle}</p>}
    </Reveal>
  )
}

/** A button that is a real link when href exists, otherwise a clearly labelled disabled state. */
export function LinkButton({
  href,
  children,
  soonLabel,
  variant = 'ghost',
  icon,
  download,
}: {
  href: string
  children: ReactNode
  soonLabel: string
  variant?: 'primary' | 'ghost'
  icon?: ReactNode
  download?: boolean
}) {
  if (!href) {
    return (
      <span className="btn-disabled" role="link" aria-disabled="true" title="Link will be added soon">
        {icon}
        {soonLabel}
      </span>
    )
  }
  const external = /^https?:/.test(href)
  return (
    <a
      href={href}
      className={variant === 'primary' ? 'btn-primary' : 'btn-ghost'}
      {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
      {...(download ? { download: true } : {})}
    >
      {icon}
      {children}
    </a>
  )
}
