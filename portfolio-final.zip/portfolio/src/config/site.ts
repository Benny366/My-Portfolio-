/**
 * SITE CONFIG: the one file to edit for personal details and links.
 * Anything left as an empty string ('') is hidden or shown as "coming soon" automatically.
 * Values with import.meta.env come from your .env file / Vercel environment variables.
 */
const env = import.meta.env

/** Prefixes a public-folder path with the site's base path (needed on GitHub Pages sub-folders). */
export const asset = (path: string) =>
  !path || /^(https?:)?\/\//.test(path) || path.startsWith('data:') ? path : `${env.BASE_URL}${path.replace(/^\//, '')}`

export const site = {
  name: 'Nagishetti Paul Benjamin',
  shortName: 'Paul Benjamin',
  initials: 'PB',
  role: 'Computer Science Engineering Student & Aspiring Developer',
  tagline: 'Build. Innovate. Create.',
  intro:
    'I enjoy transforming ideas into practical technology solutions through programming, artificial intelligence, and interactive experiences.',
  location: 'Telangana, India',
  availability: 'Open to internship opportunities',

  github: 'https://github.com/benny366',
  linkedin: (env.VITE_LINKEDIN_URL as string | undefined) ?? '',
  email: (env.VITE_CONTACT_EMAIL as string | undefined) ?? '',
  contactFormEndpoint: (env.VITE_CONTACT_FORM_ENDPOINT as string | undefined) ?? '',
  siteUrl: (env.VITE_SITE_URL as string | undefined) ?? '',

  /** Put your PDF at public/resume/Paul_Benjamin_Resume.pdf. The buttons activate automatically. */
  resumePath: asset('resume/Paul_Benjamin_Resume.pdf'),

  /** Profile photo lives at public/profile.jpg. Replace the file to change it. */
  photo: asset('profile.jpg'),

  education: {
    institution: 'SR University',
    degree: 'Bachelor of Technology (B.Tech)',
    branch: 'Computer Science and Engineering',
    graduation: '2027',
    location: 'Telangana, India',
    showCgpa: env.VITE_SHOW_CGPA === 'true',
    cgpa: (env.VITE_CGPA as string | undefined) ?? '',
  },
}
