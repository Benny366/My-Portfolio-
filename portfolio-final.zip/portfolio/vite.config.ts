import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// BASE_PATH is "/" for Vercel / custom domains and "/<repo-name>/" for GitHub Pages.
// The GitHub Actions workflow sets it automatically.
export default defineConfig({
  base: process.env.BASE_PATH || '/',
  plugins: [react()],
})
