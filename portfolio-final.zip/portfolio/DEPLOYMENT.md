# Deployment Guide (Beginner Friendly)

You will do three things: put the code on GitHub, connect GitHub to Vercel, then (optionally) attach a custom domain.
Everything below is free. No passwords or secret keys go into the website code.

---

## Part 0: Fill in your details first

1. **Resume:** copy your PDF to `public/resume/Paul_Benjamin_Resume.pdf`.
2. **Contact form (so it really sends email):**
   - Go to https://formspree.io and create a free account.
   - Click **New Form**, enter the email where you want messages, and create it.
   - Copy the form URL, which looks like `https://formspree.io/f/abcdwxyz`.
   - Keep it for Part 2. (This URL is public by design and is safe in the browser.)
3. **LinkedIn / email:** have your LinkedIn profile URL and (optionally) your public email ready.
4. **Projects:** open `src/data/projects.ts` and paste real GitHub repo links into `github` and real demo links into `demo`. Leave a field empty `''` if the link does not exist yet.
5. Test locally: `npm install`, then `npm run dev`.

---

## Part 1: Put the code on GitHub

1. Install Git (https://git-scm.com) if you don't have it.
2. On https://github.com click **New repository**. Name it `portfolio`. Keep it **Public** (or Private; Vercel works with both). Do NOT tick "Add a README". Click **Create repository**.
3. In a terminal inside the project folder, run:

```bash
git init
git add .
git commit -m "Initial portfolio"
git branch -M main
git remote add origin https://github.com/benny366/portfolio.git
git push -u origin main
```

If Git asks you to sign in, use your GitHub login (or a Personal Access Token if it asks for a password).
The `.env` file is already ignored by `.gitignore`, so your local settings are not uploaded.

---

## Part 2A: Deploy on GitHub Pages (free, and the easiest since your code is already on GitHub)

**Important:** GitHub Pages cannot run this project straight from the repository. If you set Pages to "Deploy from a branch", it just shows your README as a plain page (a bare heading and nothing else). The project must be *built* first. This repo includes a workflow (`.github/workflows/deploy.yml`) that builds and publishes it for you.

1. Make sure the whole project, including the hidden `.github` folder, is pushed to the `main` branch of your repository.
   (On github.com you can drag-and-drop upload, but the hidden `.github` folder is easy to miss. Using `git push` as in Part 1 is safer.)
2. On GitHub open your repository, then **Settings -> Pages**.
3. Under **Build and deployment -> Source**, choose **GitHub Actions** (NOT "Deploy from a branch").
4. Open the **Actions** tab. The "Deploy to GitHub Pages" run starts on every push to `main` (or click **Run workflow**). Wait for the green check.
5. Your site is live at `https://benny366.github.io/<repository-name>/`.
6. Optional settings (contact form, LinkedIn, email): **Settings -> Secrets and variables -> Actions -> Variables tab -> New repository variable**. Add `VITE_CONTACT_FORM_ENDPOINT`, `VITE_LINKEDIN_URL`, `VITE_CONTACT_EMAIL`, then re-run the workflow.

Tip: if you name the repository exactly `benny366.github.io`, the site is served at `https://benny366.github.io/` with no sub-folder.

---

## Part 2B: Deploy on Vercel (automatic deployments + HTTPS)

1. Go to https://vercel.com and choose **Sign Up -> Continue with GitHub**.
2. Click **Add New -> Project**, find your `portfolio` repository and click **Import**.
3. Vercel detects **Vite** automatically. Keep the defaults:
   - Build Command: `npm run build`
   - Output Directory: `dist`
4. Open **Environment Variables** and add (names must match exactly):

| Name | Value |
| --- | --- |
| `VITE_CONTACT_FORM_ENDPOINT` | your Formspree URL |
| `VITE_LINKEDIN_URL` | your LinkedIn profile URL |
| `VITE_CONTACT_EMAIL` | your public email (optional) |
| `VITE_SITE_URL` | your final site URL (optional, add after you know it) |
| `VITE_SHOW_CGPA` / `VITE_CGPA` | only if you want CGPA shown |

5. Click **Deploy**. After about a minute you get a live link like `https://portfolio-xxxx.vercel.app`. **HTTPS is on automatically.**
6. **Automatic updates:** from now on, every `git push` to `main` redeploys the site by itself.

If you change an environment variable later, go to **Deployments -> ... -> Redeploy**, because these values are baked in at build time.

---

## Part 3: Custom domain (optional, Vercel)

1. Buy a domain from any registrar (or use Cloudflare Registrar).
2. In Vercel: **Project -> Settings -> Domains -> Add** and type your domain.
3. Vercel shows DNS records to add. At your registrar (or in **Cloudflare -> DNS**) add exactly those records.
   - If you use Cloudflare, set the records to **DNS only** (grey cloud) so Vercel can issue the HTTPS certificate.
4. Wait a few minutes up to a few hours. Vercel shows a green check, and HTTPS is issued for you.
5. Set `VITE_SITE_URL` to the new domain and redeploy.

---

## Part 4: Verify production

Open your live link and check:

- [ ] Hero photo and all sections load; nav links scroll smoothly.
- [ ] Theme toggle works; mobile menu works on your phone.
- [ ] "Download Resume" downloads your PDF (shows "Resume coming soon" if you haven't added it).
- [ ] Send a test message through the contact form, then confirm it arrives in your inbox (Formspree asks you to confirm your email the first time).
- [ ] Visit `/anything-wrong` and confirm the custom 404 page appears.
- [ ] GitHub, LinkedIn and project buttons open the right pages.

## Troubleshooting

- **Contact form says "not connected":** `VITE_CONTACT_FORM_ENDPOINT` is missing. Add it in Vercel and redeploy.
- **Resume says "coming soon":** the file name must be exactly `Paul_Benjamin_Resume.pdf` inside `public/resume/`.
- **Build fails on Vercel:** run `npm run build` locally and fix the shown error; Vercel uses the same command.
